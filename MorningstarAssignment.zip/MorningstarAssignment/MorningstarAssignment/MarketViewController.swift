//
//  MarketViewController.swift
//  MorningstarAssignment
//
//  Created by Prem Ranjan on 31/07/17.
//  Copyright © 2017 Prem Ranjan. All rights reserved.
//

import UIKit

class MarketViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @IBAction func djAction(_ sender: UIButton) {
    }
    
    @IBAction func nseAction(_ sender: UIButton) {
    }

    @IBAction func bseAction(_ sender: UIButton) {
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "bse"{
            (segue.destination as! ViewController).segmentIndex = 0
        }else if segue.identifier == "nse"{
            (segue.destination as! ViewController).segmentIndex = 1
        }else{
            (segue.destination as! ViewController).segmentIndex = 2
        }
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
