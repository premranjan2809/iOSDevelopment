//
//  DataListsView.swift
//  MorningstarAssignment
//
//  Created by Prem Ranjan on 28/07/17.
//  Copyright © 2017 Prem Ranjan. All rights reserved.
//
import UIKit


class DataListsView: UIView,NibLoadableView {

    public var dataSoutce : [Stok?]?{
        didSet{
            self.dataLists.reloadData()
        }
    }
    public var imageArray = [UIImage](){
        didSet{
            self.dataLists.reloadData()
        }
    }
    public var videoArray = [UIImage](){
        didSet{
            self.dataLists.reloadData()
        }
    }
    
    @IBOutlet weak var dataLists: UITableView!{
        didSet{
            let nib = UINib(nibName: DataCell.nibName, bundle: nil)
            self.dataLists.register(nib,forCellReuseIdentifier: DataCell.defaultReuseIdentifier)
            self.dataLists.tableFooterView = UIView(frame: .zero)
            
        }
    }
    override init(frame: CGRect) {
        super.init(frame: frame)
        setup()
    }
    
    required init(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)!
        if self.subviews.count == 0 {
            setup()
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    func setup() {
        
        if let view = Bundle.main.loadNibNamed(DataListsView.nibName, owner: self, options: nil)?.first as? DataListsView {
            view.frame = bounds
            view.autoresizingMask = [.flexibleWidth, .flexibleHeight]
            addSubview(view)
        }
    }

    
    
}

extension DataListsView : UITableViewDelegate{
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 50
    }
    
}
extension DataListsView : UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.dataSoutce?.count ?? 0
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: DataCell.defaultReuseIdentifier) as! DataCell
        
        cell.isSetCellColor = (indexPath.row % 2 == 0)
        cell.stock = self.dataSoutce?[indexPath.row]
        return cell
    }
    
}
