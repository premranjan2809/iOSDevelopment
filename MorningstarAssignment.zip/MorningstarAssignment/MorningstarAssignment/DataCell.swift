//
//  DataCell.swift
//  MorningstarAssignment
//
//  Created by Prem Ranjan on 28/07/17.
//  Copyright © 2017 Prem Ranjan. All rights reserved.
//

import UIKit

class DataCell: UITableViewCell,ReusableView,NibLoadableView {

   
    @IBOutlet weak var changeLbl: UILabel!
    @IBOutlet weak var priceLbl: UILabel!
    @IBOutlet weak var titleLbl: UILabel!
    private var cellCorol = UIColor(red: 246.0/255.0, green: 214.0/255, blue: 207.0/255, alpha: 1)
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        self.selectionStyle = .none
    }

    var isSetCellColor = false{
        didSet{
            self.backgroundColor = isSetCellColor ? cellCorol : UIColor.white
        }
    }
    var stock : Stok?{
        didSet{
            self.titleLbl.text = stock?.stokName
            self.priceLbl.text = stock?.currentPrice
            self.changeLbl.text = stock?.change
        }
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    
    
    
}
