//
//  NewsViewController.swift
//  MorningstarAssignment
//
//  Created by Prem Ranjan on 31/07/17.
//  Copyright © 2017 Prem Ranjan. All rights reserved.
//

import UIKit

class NewsViewController: UIViewController {

    var news = ["Prakash Javadekar Says BJP has no Role in Desertion of Gujarat Congress MLAs","Apple iPad Pro 10.5-Inch Review: The Ecosystem That you Always Needed","Robert Pattinson Was Almost Fired from Twilight for Not Smiling","Amitabh Bachchan Advised Me to Never Take a Break: Anil Kapoor","Cheteshwar Pujara Calls His Father 'Worst and Best Critic"]
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    @IBOutlet weak var newsLists: UITableView!
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

}
extension NewsViewController : UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.news.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell()
        cell.textLabel?.text = self.news[indexPath.row]
        
        return cell
    }
}
