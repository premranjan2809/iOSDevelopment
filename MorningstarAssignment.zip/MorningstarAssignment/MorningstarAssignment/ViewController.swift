//
//  ViewController.swift
//  MorningstarAssignment
//
//  Created by Prem Ranjan on 28/07/17.
//  Copyright © 2017 Prem Ranjan. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var marketSegment: UISegmentedControl!
    var stocks = [Stok?]()
    public var segmentIndex = 0
	override func viewDidLoad() {
		super.viewDidLoad()
		// Do any additional setup after loading the view, typically from a nib.
        self.marketSegment.selectedSegmentIndex = self.segmentIndex
		self.updateBSEList()
	}
    @IBOutlet weak var stocksList: DataListsView!

    @IBAction func marketSlectionValueChanged(_ sender: UISegmentedControl) {
        
        switch sender.selectedSegmentIndex {
        case 0:
            self.updateBSEList()
        case 1:
            print("NSE Selected")
        case 2:
            print("DOW J. Selected")
        default: break
        }
    }
    @IBAction func backAction(_ sender: UIButton) {
        self.dismiss(animated: true, completion: nil)
    }
    
    private func updateBSEList(){
        
        self.stocks.removeAll()
        for item in JSONDataLoder.shared.getMaketData(){
            let data = item as [String : AnyObject]
                stocks.append(Stok(json: data))
        }
        defer{
            self.stocksList.dataSoutce = self.stocks
        }
        
    }
	override func didReceiveMemoryWarning() {
		super.didReceiveMemoryWarning()
		// Dispose of any resources that can be recreated.
	}


}

