//
//  JSONDataLoder.swift
//  MorningstarAssignment
//
//  Created by Prem Ranjan on 30/07/17.
//  Copyright © 2017 Prem Ranjan. All rights reserved.
//

import Foundation
class JSONDataLoder{

    // Can't init is singleton
    private init() { }
    
    // MARK: Shared Instance
    
    static let shared = JSONDataLoder()
    
    public func getMaketData()->[Dictionary<String,String>]{
        let marketData = [["StokName" :"Unitech Ltd.","currentPrice":"7.82","change":"+91.94"],
                          ["StokName" :"Videocon Industries.","currentPrice":"26.35","change":"+91.94"],
                          ["StokName" :"UCO Bank.","currentPrice":"34.70","change":"+3.58"],
                          ["StokName" :"Reliance Industries.","currentPrice":"1471.15","change":"+2.06"],
                          ["StokName" :"Cipla.","currentPrice":"551.00","change":"+1.50"]]
        
        return marketData
    }
}
