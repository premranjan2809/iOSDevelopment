
//  MorningstarAssignment
//
//  Created by Prem Ranjan on 28/07/17.
//  Copyright © 2017 Prem Ranjan. All rights reserved.
//
import Foundation
import UIKit

struct Stok {
    
    var stokName: String?
    var currentPrice: String?
    var change: String?
}


extension Stok {
    
    private struct Key  {
        static let stokName = "StokName"
        static let currentPrice = "currentPrice"
        static let change = "change"
        
    }
    
    //initializer
    init?(json: [String: AnyObject]){
        self.stokName = json[Key.stokName] as? String
        self.currentPrice = json[Key.currentPrice] as? String
        self.change = json[Key.change] as? String
    }
    
}

















