//
//  ViewController.swift
//  Message
//
//  Created by TradeSocio on 14/12/17.
//  Copyright © 2017 Prem Ranjan. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController {

    @IBOutlet weak var loadingLbl: UILabel!
    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var messageTextField: UITextField!
    private var activeTextField : UITextField?
    fileprivate var timer : Timer! = nil
    fileprivate var dotIndex = 0
    fileprivate let dotArray = [ "" ,".","..","..."]
    fileprivate lazy var fetchedResultsController: NSFetchedResultsController<Message> = {
        // Create Fetch Request
        let fetchRequest: NSFetchRequest<Message> = Message.fetchRequest()
        
        fetchRequest.sortDescriptors = [NSSortDescriptor(key: "createdAt", ascending: true)]
        
        // Create Fetched Results Controller
        let fetchedResultsController = NSFetchedResultsController(fetchRequest: fetchRequest, managedObjectContext: (self.context), sectionNameKeyPath: nil, cacheName: nil)
        
        // Configure Fetched Results Controller
        fetchedResultsController.delegate = self
        
        return fetchedResultsController
    }()
    @IBOutlet weak var chatList: UITableView!
    var context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        let nib = UINib(nibName: "ChatCell", bundle: nil)
        self.chatList.register(nib, forCellReuseIdentifier: "ChatCell")
         self.chatList.register(UINib(nibName: "ReciveChatCell", bundle: nil), forCellReuseIdentifier: "ReciveChatCell")
        self.setNotificationKeyboard()
        self.loadingLbl.alpha = 0
        self.updateView()
    
    }
    fileprivate func updateView(){
        do {
            try  self.fetchedResultsController.performFetch()
        } catch {
            let fetchError = error as NSError
            print("Unable to Perform Fetch Request")
            print("\(fetchError), \(fetchError.localizedDescription)")
        }
    }
    override func viewDidLayoutSubviews() {
        self.updateTableContentInset(forTableView: chatList)
    }
    
    func updateTableContentInset(forTableView tv: UITableView) {
        let numSections = tv.numberOfSections
        var contentInsetTop = tv.bounds.size.height - 60
        
        for section in 0..<numSections {
            let numRows = tv.numberOfRows(inSection: section)
            let sectionHeaderHeight = tv.rectForHeader(inSection: section).size.height
            let sectionFooterHeight = tv.rectForFooter(inSection: section).size.height
            contentInsetTop -= sectionHeaderHeight + sectionFooterHeight
            for i in 0..<numRows {
                let rowHeight = tv.rectForRow(at: IndexPath(item: i, section: section)).size.height
                contentInsetTop -= rowHeight
                if contentInsetTop <= 0 {
                    contentInsetTop = 0
                    break
                }
            }
            // Break outer loop as well if contentInsetTop == 0
            if contentInsetTop == 0 {
                break
            }
        }
        tv.contentInset = UIEdgeInsetsMake(contentInsetTop, 0, 0, 0)
    }
    
    private func setNotificationKeyboard ()  {
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWasShown(notification:)), name: .UIKeyboardWillShow, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillBeHidden(notification:)), name: .UIKeyboardWillHide, object: nil)
    }
    
    @objc func keyboardWasShown(notification: NSNotification)
    {
        
        var userInfo = notification.userInfo!
        var keyboardFrame:CGRect = (userInfo[UIKeyboardFrameBeginUserInfoKey] as! NSValue).cgRectValue
        keyboardFrame = self.view.convert(keyboardFrame, from: nil)
        let bottomOffset = CGPoint(x: 0, y: (scrollView.contentSize.height - (keyboardFrame.height * 2) + self.messageTextField.frame.height))
        scrollView.setContentOffset(bottomOffset, animated: true)
        
    }
    // when keyboard hide reduce height of scroll view
    @objc func keyboardWillBeHidden(notification: NSNotification){
        let bottomOffset = CGPoint(x: 0, y: scrollView.contentSize.height - 568)
        scrollView.setContentOffset(bottomOffset, animated: true)
        self.loadViewIfNeeded()
    }
    
    @IBAction func sendAction(_ sender: UIButton) {
        if self.messageTextField.text != ""{
            
            self.loadingLbl.alpha = 1
            timer = Timer.scheduledTimer(timeInterval: 0.25, target: self, selector: #selector(timerCallback), userInfo: nil, repeats: true)
            let message = Message(context: context)
            message.createdAt = Date().timeIntervalSince1970
            message.isRecivedMessage = false
            message.messageText = self.messageTextField.text
            self.messageTextField.text = ""
            do{
                try self.context.save()
                let when = DispatchTime.now() + 3
                DispatchQueue.main.asyncAfter(deadline: when) {
                    self.simulateReciveMessage()
                }
            }catch{
                print(error)
            }
        }
    }
    @objc func timerCallback() {
        self.loadingLbl.text = dotArray[dotIndex]
        dotIndex = dotIndex < 3 ? dotIndex + 1 : 0
    }
    func simulateReciveMessage(){
        
        let message = Message(context: context)
        message.createdAt = Date().timeIntervalSince1970
        message.messageText = "Here's a text message that was sent a few minutes ago..."
        message.isRecivedMessage = true
        self.loadingLbl.alpha = 0
         self.timer.invalidate()
        do {
            try self.context.save()
        } catch let err {
            print(err)
        }
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    override func viewWillAppear(_ animated: Bool) {
      self.chatList.estimatedRowHeight = 10
        self.chatList.rowHeight = UITableViewAutomaticDimension
        self.chatList.scrollToBottom(animated: false)
    }
}
extension ViewController : UITextFieldDelegate{
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        
        self.activeTextField = textField

    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
}
extension ViewController : UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        guard let messages = fetchedResultsController.fetchedObjects else { return 0 }
        return messages.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
         let message = fetchedResultsController.object(at: indexPath)
        if (message.isRecivedMessage){
            let cell = self.chatList.dequeueReusableCell(withIdentifier: "ReciveChatCell")! as! ReciveChatCell
           
            cell.messageLbl.text = message.messageText
            return cell
        }else{
            let cell = self.chatList.dequeueReusableCell(withIdentifier: "ChatCell")! as! ChatCell
            cell.messageLbl.text = message.messageText
            return cell
        }
    }
}

extension UITableView {
    func scrollToBottom(animated: Bool) {
        let y = contentSize.height - frame.size.height
        setContentOffset(CGPoint(x: 0, y: (y<0) ? 0 : y), animated: animated)
    }
}

extension ViewController: NSFetchedResultsControllerDelegate {
    
    func controllerWillChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>) {
        chatList.beginUpdates()
    }
    
    func controllerDidChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>) {
        chatList.endUpdates()
        self.updateView()
    }
    
    func controller(_ controller: NSFetchedResultsController<NSFetchRequestResult>, didChange anObject: Any, at indexPath: IndexPath?, for type: NSFetchedResultsChangeType, newIndexPath: IndexPath?) {
        
        switch (type) {
        case .insert:
            if let indexPath = newIndexPath {
                chatList.insertRows(at: [indexPath], with: .fade)
                let when = DispatchTime.now() + 0.5
                DispatchQueue.main.asyncAfter(deadline: when) {
                    self.chatList.scrollToBottom(animated: true)
                }
            }
            break;
        case .delete:
            if let indexPath = indexPath {
                chatList.deleteRows(at: [indexPath], with: .fade)
                let when = DispatchTime.now() + 3
                DispatchQueue.main.asyncAfter(deadline: when) {
                    self.chatList.scrollToBottom(animated: true)
                }
            }
            break;
        default:
            print("...")
        }
    }
}
