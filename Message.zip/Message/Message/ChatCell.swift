//
//  ChatCell.swift
//  Message
//
//  Created by TradeSocio on 14/12/17.
//  Copyright © 2017 Prem Ranjan. All rights reserved.
//

import UIKit

class ChatCell: UITableViewCell {

    @IBOutlet weak var mesageContainerView: UIView!{
        didSet{
            self.mesageContainerView.layer.cornerRadius = 10
        }
    }
    @IBOutlet weak var messageLbl: UILabel!{
        didSet{
            self.messageLbl.sizeToFit()
        }
    }
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
